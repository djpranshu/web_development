'use strict';
 
angular.module('ForgetPassword')
 
.controller('ForgetPasswordController',
    ['$scope','$rootScope',
    function ($scope , $rootScope) {
 
       console.log("In ForgetPassword ..");

    }]);