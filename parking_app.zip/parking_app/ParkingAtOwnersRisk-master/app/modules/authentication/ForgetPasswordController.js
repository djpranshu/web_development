'use strict';
 
angular.module('ForgetPassword')
 
.controller('ForgetPassword',
    ['$scope','$rootScope',
    function ($scope , $rootScope) {
    	
       console.log("In ForgetPassword ..");

    }]);